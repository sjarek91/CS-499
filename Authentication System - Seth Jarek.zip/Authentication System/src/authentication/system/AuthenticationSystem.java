/*
 * The purpose of this program is to determine if a user is authorized
 * to have access to the computer system.  Once it is determined that 
 * access has been granted into the system, the program will greet each user
 * based on their role at the zoo.  
 */
package authentication.system;

import java.util.Scanner;
import java.io.File;
import java.security.MessageDigest;
import javax.swing.JOptionPane;  // Did a lot of research to figure out how to create prompts

/**
 *
 * @author sjare
 */
public class AuthenticationSystem {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        
        // Ask user if they wish to continue with program. (Yes or No)
        String prompt = "Do you wish to continue?";
        String title = "";
        int reply = JOptionPane.showConfirmDialog(null, prompt, title, JOptionPane.YES_NO_OPTION);// Using YES_NO_OPTION to give the user the chance to exit
        if (reply == JOptionPane.NO_OPTION) { // Using NO_OPTION so that when the user selects "No" the program will exit
            JOptionPane.showMessageDialog(null, "Thank you for visiting! \nPlease come back soon!"); // When the user exits, displays a message to come back soon
            System.exit(0);// exits the program upon request
            }
        
            //set i to 0 to cycle through user attempts
            int i = 0;

            // Create a while loop to allow user to make 3 valid attemps
            while (true) {

                // Prompt the user to enter a username in the input dialog window
                String username;
                JOptionPane.showMessageDialog(null, "REMINDER: All usernames"
                        + " and passwords are case sensitive!!");
                username = JOptionPane.showInputDialog("Please enter username: ");
                
                if(username == null){
                    System.exit(0);
                }

                // Prompt the user to enter a password in the input dialog window
                String password;
                password = JOptionPane.showInputDialog("Please enter password: ");
                if(password == null){
                    System.exit(0);
                }


                // Use message digest five (MD5) hash to convert password
                String original = password;  //Set the actual password inputted by the user to be converted to MD5
                MessageDigest md = MessageDigest.getInstance("MD5");
                md.update(original.getBytes());
                byte[] digest = md.digest();
                StringBuffer sb = new StringBuffer();
                for (byte b : digest) {
                    sb.append(String.format("%02x", b & 0xff));
                }
                
                // Displaying the original/digested password using JOptionPane
                JOptionPane.showMessageDialog(null, "Original password: " + password +
                        "\nDigested password :" + sb.toString());

                // Using the boolean function to determine if a login attempt is valid or not 
                boolean granted = false;

                //Open credentials.txt file
                Scanner credentials = new Scanner(new File("credentials.txt"));

                // Search for credentials in the credentials file
                while (credentials.hasNextLine()) {
                    String txt = credentials.nextLine();// Reading the text from credentials file
                    String column[] = txt.split("\t");// Using the split to read the text by column separated by a tab

                    /* The next portion will compare user entered information 
                    with the information the credentials file provided to 
                    determine if access will be granted */
                    
                    // Checking if the username matches
                    if (column[0].trim().equals(username)) {

                        if (column[1].trim().equals(sb.toString()))// Validate password entered
                        {

                            granted = true; // Setting boolean value to true if password is correct

                            /*Using the scanner to search the role 
                            files using the credentials file.  Taking the column
                            with role names and add ".txt" to the end to read 
                            the corresponding file name for each role*/
                            
                            // Using a new scanner within the loop to scan the file names
                            Scanner authRole = new Scanner(new File(column[3].trim() + ".txt"));

                            //Display the information stored in the role file
                            while (authRole.hasNextLine()) {
                                JOptionPane.showMessageDialog(null, authRole.nextLine());
                            }
                            break;
                        }
                    }
                }
                /* After role information is displayed, ask user if they want
                to exit the program.
                 */
                if (granted) {
                    prompt = "Do you wish to log out?";
                    title = "";
                    reply = JOptionPane.showConfirmDialog(null, prompt, title, JOptionPane.YES_NO_OPTION); // using YES_NO_OPTION to give the user a choice
                    if (reply == JOptionPane.YES_OPTION) {// Using YES_OPTION this time to have user exit with "Yes"
                        JOptionPane.showMessageDialog(null, "Thank you for visiting!"
                                + " \nPlease come back soon!"); // Thank user and offer to come back soon
                        System.exit(0);// Exit program when they are finished and select "Yes"
                    } else {
                        granted = false; // If user is not done, username box will appear again
                    }
                } // Increment the invalid attempts by 1 until it reaches 3.
                else {
                    i++;

                    // Once maximum attempts have been entered, Display error message
                    if (i == 3) {
                        JOptionPane.showMessageDialog(null, "Sorry, you have been locked out of "
                                + "the system...\nPlease try agian later."); // Let user know they are locked out because of too many invalid attempts
                        break;

                    } // Display error message and allow another attempt.
                    else {
                        JOptionPane.showMessageDialog(null, "INVALID, PLEASE TRY AGAIN!"); // Give another try if they still have valid attempts remaining 
                    }
                }
            }
        }

    }
